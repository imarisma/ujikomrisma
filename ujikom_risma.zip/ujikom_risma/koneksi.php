 <?php
$koneksi=mysqli_connect('localhost','root','','praukk_risma_rpl2');
?> 
