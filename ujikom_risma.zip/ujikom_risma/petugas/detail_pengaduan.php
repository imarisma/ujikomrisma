<?php
include("css.php");
?>

<!DOCTYPE html>
<html lang="en">

<body id="page-top">

<div class="card shadow">
    <div class="card-header">
        Detail Pengaduan
    </div>
    <?php
    require'../koneksi.php';
    $sql=mysqli_query($koneksi, "SELECT * FROM pengaduan WHERE id_pengaduan='$_GET[id]'");
    $data=mysqli_fetch_array($sql);
    if($sql)
    {
        ?>
    <div class="card-body">
    <div class="form-group cols-sm-6">
    <a href="?url=verifikasi_pengaduan" class="btn btn-primary btn-icon-split">
        <span class="icon text-white-50">
            <i class="fas fa-arrow-Left"></i>
    </span>
    <span class="text">Kembali</span>
    </a>

    <a href="proses.php?id=<?php echo $data['id_pengaduan']; ?>" class="btn btn-danger btn-icon-split" onclick="return confirm('yakin akan di proses?')">
        <span class="icon text-white-50">
            <i class="fas fa-check"></i>
    </span>
    <span class="text">Proses Verifikasi</span>
    </a>
   
        <form action="" method="post" class="form_horizontal" enctype="multipart/form-data">
            
            <div class="form-group cols-sm-6">
                <label>Tanggal Pengaduan</label>
                <input type="text" name="tgl_pengaduan" value="<?php echo $data['tgl_pengaduan']; ?>" class="form-control"readonly>
            </div>
            
            <div class="form-group cols-sm-6">
                <label>Isi Laporan</label>
                <textarea class="form-control" rows="7" name="isi_laporan" readonly>
                    <?php echo $data['isi_laporan']; ?>

            </textarea>
            </div>
            <div class="form-group cols-sm-6">
                <label>Bukti Foto</label>
                <div>
                <img src="../foto/<?php echo $data['foto']; ?>" widht=800>
            </div>
            </div>         
            <?php } ?>
            </form> 
        </body>

</html>