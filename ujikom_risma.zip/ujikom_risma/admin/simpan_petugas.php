<?php
require "../koneksi.php";
$nama=$_POST['nama_petugas'];
$user=$_POST['username'];
$pass=$_POST['password'];
$telp=$_POST['telp'];
$level=$_POST['level'];

$cek = "SELECT * FROM petugas WHERE username='$_POST[username]'";
$proses =mysqli_query($koneksi, $cek);

if (mysqli_num_rows($proses) > 0) {

    ?>
    <script type="text/javascript">
    alert ('username sudah terdaftar');
    window.location='admin.php?url=lihat_petugas';
</script>
<?php


} else {

$sql=mysqli_query($koneksi, "INSERT INTO petugas (nama_petugas,username,password,telp,level) VALUES ('$nama', '$user', '$pass', '$telp', '$level')");

if ($sql)
{

?>
<script type="text/javascript">
    alert ('Data Berhasil Diubah');
    window.location='admin.php?url=lihat_petugas';
</script>
<?php

}
}

?>                       