<?php
include("css.php");
?>

<!DOCTYPE html>
<html lang="en">

<body id="page-top">

<div class="card shadow">
    <div class="card-header">
        Edit Data Petugas
    </div>
    <div class="card-body">

        <?php
        require '../koneksi.php';
        $sql=mysqli_query($koneksi, "SELECT * FROM petugas WHERE id_petugas='$_GET[id]'");
        if($data=mysqli_fetch_array($sql))
        {   
        ?>
        <form action="update_petugas.php" method="post" class="form_horizontal" enctype="multipart/form-data">
            <div class="form-group cols-sm-6">
                <label>ID Petugas</label>
                <input type="text" name="id_petugas" value="<?php echo $data['id_petugas']; ?>" class="form-control" readonly>
            </div>
            <div class="form-group cols-sm-6">
                <label>Nama Petugas</label>
                <input type="text" name="nama_petugas" value="<?php echo $data['nama_petugas']; ?>" class="form-control">
            </div>
            <div class="form-group cols-sm-6">
                <label>Username</label>
                <input type="text" name="username" value="<?php echo $data['username']; ?>" class="form-control">
            </div>
            <div class="form-group cols-sm-6">
                <label>Password</label>
                <input type="text" name="password" value="<?php echo $data['password']; ?>" class="form-control">
            </div>
            <div class="form-group cols-sm-6">
                <label>Telp</label>
                <input type="number" name="telp" value="<?php echo $data['telp']; ?>" class="form-control">
            </div>
            <div class="form-group cols-sm-6">
                <label>Level</label>
                <select class="form-control" name="level">
                    <option value="<?php echo $data['level']; ?>" ></option>
                    <option value="admin">admin</option>
                    <option value="petugas">petugas</opition>
                </selecet>
            </div>
           
            <div class="form-group col-sm-6 mb-4">
                <input type="submit" value="Simpan" class="btn btn-primary">
                <input type="reset" value="kosongkan" class="btn btn-warning">
</div>
</form>   
    <?php } ?>
</div>
</body>

</html>