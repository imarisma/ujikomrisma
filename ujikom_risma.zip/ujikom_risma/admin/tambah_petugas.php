<?php
include("css.php");
?>

<!DOCTYPE html>
<html lang="en">

<body id="page-top">

<div class="card shadow">
    <div class="card-header">
        Tambah Petugas
    </div>
    <div class="card-body">
        <form action="simpan_petugas.php" method="post" class="form_horizontal" enctype="multipart/form-data">
            <div class="form-group col-lg-6">
                <label>Nama Petugas</label>
                <input type="text" name="nama_petugas" value="" class="form-control" required>
            </div>
            <div class="form-group col-lg-6">
                <label>Username</label>
                <input type="text" name="username" value="" class="form-control" required>
            </div>
            <div class="form-group col-lg-6">
                <label>Password</label>
                <input type="text" name="password" value="" class="form-control" required>
            </div>
            <div class="form-group col-lg-6">
                <label>Telp</label>
                <input type="text" name="telp" value="" class="form-control" required>
            </div>
            <div class="form-group col-lg-6">
                <label>Level</label>
                <select class="form-control" name="level">
                    <option> ==pilih== </option>
                    <option value="admin">admin</option>
                    <option value="petugas">petugas</option>
                </select>
            </div>
          
            <div class="form-group col-sm-6 mt-3">
                <input type="submit" value="Simpan" class="btn btn-primary">
                <input type="reset" value="kosongkan" class="btn btn-warning">
            </div> 
</form>   
</body>

</html>